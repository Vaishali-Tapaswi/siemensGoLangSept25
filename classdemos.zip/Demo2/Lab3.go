package main 
import "fmt"

type tostr interface {
	Convert() string 
}

type Vertex  struct {
	X int
	Y int
}

func (v1 Vertex) Convert() string{
	fmt.Println("Convert running with Vertex", v1)
	return "Converted"
}


func main(){
	v1 := Vertex{}
	var myinterface tostr
	myinterface = v1
	myinterface.Convert()
	fmt.Println(v1)
}
