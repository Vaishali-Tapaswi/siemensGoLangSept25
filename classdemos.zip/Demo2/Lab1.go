package main 
import "fmt"

type Vertex  struct {
	X int
	Y int
}
func main(){
	v1 := Vertex
	v1.X = 101
	v1.Y =202
	fmt.Println(v1)
	v1 = Vertex{1, 2}  
	fmt.Println(v1)
	v1 = Vertex{X: 1, Y:100} 
	fmt.Println(v1)

	p  := &Vertex{1, 2} // has type *Vertex
	fmt.Println(*p)
}