package main 
import "fmt"

type Vertex  struct {
	X int
	Y int
}

func (thisv Vertex) printMethod(){
	fmt.Println("Print Vertext Details - ", thisv.X, thisv.Y)
}
func (thisv *Vertex) shiftMethod(dx,dy int ){
	fmt.Println("Print Vertext Details - ", thisv.X, thisv.Y)
	thisv.X = thisv.X+ dx
	thisv.Y = thisv.Y+ dy
	fmt.Println("Shifting Vertext Details - ", thisv.X, thisv.Y)
}

/* This will not have any impact
func printfn(v Vertex){
	fmt.Println("Print Vertext Details - ", v.X, v.Y)
	v.X=100
}
*/
func printfn(v *Vertex){
	fmt.Println("Print Vertext Details - ", v.X, v.Y)
	v.X=100
}
func main(){
	v1 := Vertex{1, 2}  
	fmt.Println(v1)
	printfn(&v1)
	v1.printMethod()
	v1.shiftMethod(5,5)
	fmt.Println(v1)
}