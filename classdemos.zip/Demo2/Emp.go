package main

import "fmt"

type Emp struct {
 EmpNo  int
 Name   string
 Salary float64
}

func (e Emp) print() {
 fmt.Println(e.EmpNo, e.Name, e.Salary)
}

func (e *Emp) salaryIncr(percent float64) {
 updatedsalary := e.Salary + (e.Salary*percent)/100
 e.Salary = updatedsalary
}

type EmpManager struct {
 Employees []Emp
}

func (emp *EmpManager) add(e Emp) {
 emp.Employees = append(emp.Employees, e)
}

func (emp EmpManager) print() {
 for _, e := range emp.Employees {
  fmt.Println("Name: ", e.Name, "EmpNo: ", e.EmpNo, e.Salary)
 }
}

func main() {

 emp := Emp{
  EmpNo:  11,
  Name:   "ABC",
  Salary: 124.11,
 }
 emp.print()
 empmanager := EmpManager{
  Employees: make([]Emp, 0),
 }
 empmanager.add(emp)
 emp.salaryIncr(10)

 empmanager.print()

}
 