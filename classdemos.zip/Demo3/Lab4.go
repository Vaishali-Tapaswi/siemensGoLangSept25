package main

import (
	"fmt"
	"strconv"
)

func inputMethod() (str1 string, str2 string) {

	fmt.Print("Enter first number:")
	fmt.Scanln(&str1)
	fmt.Print("Enter 2nd number:")
	fmt.Scanln(&str2)
	return
}

func calculate(str1 string, str2 string) (div int) {
	defer fmt.Println("defer in calculate ")
	defer func() {
		if r := recover(); r != nil {
			fmt.Println("Recovered in f", r)
		}
	}()
	n1, err := strconv.Atoi(str1)
	n2, _ := strconv.Atoi(str2)
	if err != nil {
		panic(err)
	}
	div = n1 / n2
	fmt.Println("Division is:", div)
	return
}

func main() {
	defer fmt.Println("defer in main function ")
	str1, str2 := inputMethod()
	calculate(str1, str2)
}
