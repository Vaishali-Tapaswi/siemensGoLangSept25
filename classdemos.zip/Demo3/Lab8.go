package main

import (
 "encoding/json"
 "fmt"
)

type Emp struct {
	EmpNo int     `json:"empno"`
	Name  string  `json:"name"`
	Salary   float64 `json:"sal"`
}

func main() {

 emp1 := Emp{
  EmpNo:  101,
  Name:   "Vikram",
  Salary: 75000.50,
 }

 fmt.Printf("Original Struct: %+v \n", emp1)

 jsonEmp, err := json.Marshal(emp1)
 fmt.Println("JSON String: ", string(jsonEmp), " Error: ", err)
 err = json.Unmarshal(jsonEmp, &emp1)
 fmt.Println("Unmarshal Error: ", err)
 fmt.Printf("Unmarshalled Struct: %+v", emp1)

}
 