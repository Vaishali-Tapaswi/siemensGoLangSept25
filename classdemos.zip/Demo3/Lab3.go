package main 

import "fmt"

func main(){
	defer fmt.Println("..............Defer in main")
	defer test()
	fmt.Println("Starting main ")
	demo(4)
	fmt.Println("Ending  main ")
}
func test() {
	r := recover();
	fmt.Println("in test function, current r is " , r)
    if  r != nil {          fmt.Println("Recovered in test function ", r)}
    }
func demo(i int) {
	defer fmt.Println("............trying to catch exception")
	fmt.Println("starting line in g")
    if i > 3 {
		fmt.Println("Panicking!")
        panic(fmt.Sprintf("Panic statement %v", i))
    }
	fmt.Println("ending line in Printing in g", i)
}




