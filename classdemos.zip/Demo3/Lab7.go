package main

import (
	"fmt"
	"net/http"
	"os"
	"io"
)
func main() {
	url:="https://jsonplaceholder.typicode.com/todos/" + os.Args[1]
	resp, err := http.Get(url)
	fmt.Println("Done ")
	fmt.Println(" err ", err)
	fmt.Println("Status = ", resp.Status)
	b, err := io.ReadAll(resp.Body)
	fmt.Println("Body COntent " ,string(b) , err)
}