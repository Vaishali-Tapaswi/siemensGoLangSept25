package main
import (
	"fmt"
	"github.com/magiconair/properties"
)
func main(){
		p := properties.MustLoadFile("./config.properties", properties.UTF8)
		v := p.GetString("host", "default value can't read prop file")
		fmt.Println(v)
		port := p.GetInt32("port", 80)
		fmt.Println(port)
}
