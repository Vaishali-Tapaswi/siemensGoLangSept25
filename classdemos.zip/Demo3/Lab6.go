package main

import (
	"fmt"
	"net/http"
	"io"
)

func main() {

	http.HandleFunc("/",
		func(w http.ResponseWriter, r *http.Request) {
			//fmt.Fprintf(w, "<h1>Index Page</h1>")
			w.Write([]byte("Hello World !!"))
			
		})
	http.HandleFunc("/hello",
		func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "<h1>Hello Page !!</h1>")
		})
	
	http.HandleFunc("/simple",
		func(w http.ResponseWriter, r *http.Request) {
			io.WriteString(w, "<body bgcolor='cyan'>Hello</body>")
		})

		

	fmt.Println("Starting Server on 8080...")
	http.ListenAndServe(":8080", nil)
}
