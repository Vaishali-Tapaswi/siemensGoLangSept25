package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
)

type TodoList struct {
	UserID    int    `json:"userId"`
	ID        int    `json:"id"`
	Title     string `json:"title"`
	Completed bool   `json:"completed"`
}

func main() {
	param := 1
	url := "https://jsonplaceholder.typicode.com/todos/" + strconv.Itoa(param)
	resp, err := http.Get(url)
	res, err := io.ReadAll(resp.Body)
	fmt.Println("Body: ", string(res), err)

	var todo TodoList
	json.Unmarshal(res, &todo)
	fmt.Println("Todo Title is: ", todo.Title)

	
	url2 := "https://jsonplaceholder.typicode.com/todos"
	res1, err := http.Get(url2)
	fmt.Println(" err ", err)
	fmt.Println("status :", res1.Status)
	respon, err := io.ReadAll(res1.Body)
	fmt.Println("body: ", string(respon), err)

	todolist := make([]TodoList, 200) 

	json.Unmarshal(respon, &todolist)
	fmt.Println(todolist)
	for i,v := range todolist {
		fmt.Println(i, "\t", v.UserID, "\t", v.ID, "\t", v.Title)
	}
}
