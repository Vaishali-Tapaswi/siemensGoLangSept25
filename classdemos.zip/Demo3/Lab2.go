package main 

import "fmt"

func main(){
	defer fmt.Println("..............Defer in main")
	fmt.Println("Starting main ")
	demo(4)
	fmt.Println("Ending  main ")
}
func demo(i int) {
	defer fmt.Println("............trying to catch exception")
	fmt.Println("starting line in g")
    if i > 3 {
		fmt.Println("Panicking!")
        panic(fmt.Sprintf("Panic statement %v", i))
    }
	
	fmt.Println("ending line in Printing in g", i)
}


