package main

import (
	"fmt"
	"os"
	)
func main() {	
	// no intialization
	var a1 string
	// with intialization, data type is inferred
	var a2 = "aaa"
	// short syntax
	var a3, n1 = "aaa",300.39
	/*
	a3 := "aaaa"
	n1:=300.39
	*/
	fmt.Println("Hello World !!")
	fmt.Println(os.Args)
	fmt.Println(a1)
	fmt.Println(a2)
	fmt.Println(a3)
	fmt.Printf("%T  %v", n1, n1)
	n1 = 330.330
	fmt.Println(n1)
}
