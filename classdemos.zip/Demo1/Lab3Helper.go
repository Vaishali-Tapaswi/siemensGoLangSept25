package main
import "fmt"
func calc(x,y int ) (int, int) {
	fmt.Println("in add with ", x , " and ", y)
	return x+y, x-y
}
func calc1(x,y int ) (sum, sub int) {
	fmt.Println("in add with ", x , " and ", y)
	sum, sub = x+y, x-y
	return
}