package main

import "fmt"

func main() {
	
	name := "aaa"
	fmt.Println(name)
	fmt.Println("Enter your name ")
	cnt, err := fmt.Scanln(&name)
	fmt.Println(cnt, err)
	fmt.Println(name)
	
	//marks := 20
	var marks int
	fmt.Println(marks)
	fmt.Println("Enter your marks ")
	cnt, err = fmt.Scanln(&marks)
	fmt.Println(cnt, err)
	fmt.Println(marks)
	
	no := 100/marks 
	fmt.Println("NO is ", no)
fmt.Println("Finished")
}
//func Scanln(a ...any) (n int, err error)