package main

import "fmt"

func main() {
	var num int
	fmt.Println("Enter number:")
	fmt.Scanln(&num)

	slice := make([]string, num)

	for i := 0; i < num; i++ {
		fmt.Println("Enter string:")
		fmt.Scanln(&slice[i])
	}
	fmt.Println("You entered:", slice)

    for i, v := range slice {
		fmt.Println( i,"  ", v)
	}

}
