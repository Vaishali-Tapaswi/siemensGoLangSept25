package main 
import "fmt"
func main(){
	
	primes := [6]int{2, 3, 5, 7, 11, 13}
	
	fmt.Println("Original Array" , primes, " len is ", len(primes), "cap is ", cap(primes))
	sl1 := primes[2:4] // 4 is not included
	fmt.Println("Slice 1 ", sl1 , "len is ", len(sl1), "cap is ", cap(sl1) )
	sl1[0] = 99
	sl1[1] = 100

	sl2 := primes[3:5] // 5 is not included
	fmt.Println("Slice 2 ", sl2 , "len is ", len(sl2), "cap is ", cap(sl2) )
	fmt.Println("Slice ", sl2 )
	sl2[0] = 777
	sl2[1] = 11111
	
	fmt.Println("Final " , primes)
}