package main
import "fmt"

func main(){
	n1, n2  := calc(1000,400)
	fmt.Println("Sum = ", n1, " Sub = ", n2)
	n1, n22  := calc1(10000,4000)
	fmt.Println("Sum = ", n1, " Sub = ", n22)
}