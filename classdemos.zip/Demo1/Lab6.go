package main 
import "fmt"
func main(){
	
	slice1 := make([]int, 3)
	slice1[0]=100
	slice1[1]=200
	fmt.Println(slice1 ,  " len is ", len(slice1), "cap is ", cap(slice1))
	slice1 =  append(slice1,300)

	fmt.Println(slice1 ,  " len is ", len(slice1), "cap is ", cap(slice1))
	slice1 =  append(slice1,400)
	slice1 =  append(slice1,500)
	fmt.Println(slice1 ,  " len is ", len(slice1), "cap is ", cap(slice1))
	slice1 =  append(slice1,600)
	fmt.Println(slice1 ,  " len is ", len(slice1), "cap is ", cap(slice1))

}