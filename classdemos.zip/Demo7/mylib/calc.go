package calc
import "fmt"
func Hello(str string) string{
	fmt.Println("in calc.hello with " , str)
	return "Hello, "+ str
}
func Add(no1, no2 int) int {
	fmt.Println("in calc add with ", no1, " ", no2)
	return no1+no2
}
