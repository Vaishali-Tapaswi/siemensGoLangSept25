package main 
import(
	"fmt"
	"calc"
)

func main(){
	fmt.Println("in Lab1 of libuser")
	str := calc.Hello("Vaishali")
	fmt.Println(str)
	num := calc.Add(1000,4000)
	fmt.Println("Sum = ", num)
}