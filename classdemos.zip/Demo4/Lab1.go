package main 
import "fmt"
const count=5000
func main(){
	fmt.Println("Enter a key to continue / stop")

	go printdetails("-")
	go printdetails("*")
	go printdetails("x")
	fmt.Println("End of main")

	//Stop main program from close 
	//Options - infinite for loop, scan, sleep 
	//for{}
	n:=0
	fmt.Scan(&n)
	
}

func printdetails(str string){
	for i:=1;i<count;i++{
		fmt.Print(str)
	}
}