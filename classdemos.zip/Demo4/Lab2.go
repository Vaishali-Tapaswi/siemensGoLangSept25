package main 
import ("fmt"
"time"
)
const count=5000

func main(){
	//var ch chan int
	ch := make(chan int)
	go add(1000,30000, ch)
	//wait for answer 
	fmt.Println("Waiting for channel data .........") 

	calsum := <-ch
	fmt.Println("Got  channel data ......... ", calsum)  
	calsum = <-ch
	fmt.Println("Got  channel data ......... ", calsum)  
	for{}
}

func add(n1, n2 int, ch1 chan int) {
	fmt.Println("Calculating ......")
	time.Sleep(1 * time.Second)
	fmt.Println("Sending item1......")
	sum := n1+ n2
	ch1 <- sum
	fmt.Println("Sending item2......")
	ch1 <- n1-n2
	fmt.Println("Finished sending data")
}