package main

import (
	"database/sql"
	"fmt"
	"log"
	_ "github.com/go-sql-driver/mysql" 
	"strconv"
)

type Emp struct {
	EmpNo  int     `json:"empno"`
	Name   string  `json:"name"`
	Salary float64 `json:"sal"`
}

type EmpDao struct{
	
}

const connStr = "admin:MyPassword@tcp(mysqldb1.cora8c66s2x6.us-east-1.rds.amazonaws.com:3306)/dbname"

func (dao *EmpDao) add(emp Emp) (noofrecord int64, err error) {
	fmt.Println("in add with", emp)
	db, err := sql.Open("mysql", connStr)
	if err != nil {
		fmt.Println("Error opening database:", err)
		return 0, err
	}
	defer db.Close()

	// Insert query execution
	result, err := db.Exec("INSERT INTO EmpTable (empno, ename, salary) VALUES (?, ?, ?)", emp.EmpNo, emp.Name, emp.Salary)
	if err != nil {
		fmt.Println("Error executing insert query:", err)
		return 0, err
	}

	noofrecord, err = result.RowsAffected()
	if err != nil {
		fmt.Println("Error getting rows affected:", err)
		return 0, err
	}

	if noofrecord == 0 {
		fmt.Println("No records were inserted.")
		return 0, fmt.Errorf("no records inserted")
	}

	return noofrecord, nil
}

func (dao *EmpDao) list() ([]Emp, error) {
	db, err := sql.Open("mysql", connStr)
	if err != nil {
		fmt.Println("Error opening database:", err)
		return nil, err
	}
	defer db.Close()

	rows, err := db.Query("SELECT empno, ename, salary FROM EmpTable")
	if err != nil {
		fmt.Println("Error executing select query:", err)
		return nil, err
	}
	defer rows.Close()

	var employees []Emp
	for rows.Next() {
		var emp Emp
		if err := rows.Scan(&emp.EmpNo, &emp.Name, &emp.Salary); err != nil {
			fmt.Println("Error scanning row:", err)
			return nil, err
		}
		employees = append(employees, emp)
	}

	return employees, nil
}

func main() {
	empdao := EmpDao{}
	for i := 10; i < 100; i += 10 {
		e := Emp{i, "Nameof" + strconv.Itoa(i), 1000.0}
		recount, err := empdao.add(e)
		if err != nil {
			fmt.Println("Error adding employee:", err)
		} else {
			fmt.Println("Employee", e, "added successfully, result:", recount)
		}
	}
	employees, err := empdao.list()
	if err != nil {
		log.Fatalf("Error listing employees: %v", err)
	}
	for _, v := range employees {
		fmt.Println(v)
	}
}
