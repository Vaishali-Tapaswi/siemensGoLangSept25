package main 

import (
	"fmt"
)

func main(){
	fmt.Println(Add(300,100))
	fmt.Println(Divide(300,100))
	fmt.Println(Divide(300,0))
}
func Add(no1, no2 int) int {
	return no1+no2
}
func Divide(no1 , no2 int ) (int) {
	return no1/no2;
}