package main 
import (
//	"fmt"
	"testing"
)

func TestAdd(t *testing.T){
	got := Add(4000,3000)
    if got != 7000 {
        t.Errorf("Add(4000,3000) = %d; want 7000", got)
    }
}

func TestDivide(t *testing.T){
	got := Divide(4000,400)
    if got != 10 {
        t.Errorf("Divide(4000,400) = %d; want 10", got)
    }
}


func TestDivide1(t *testing.T){
	defer func(){
		if r:= recover(); r == nil{
			t.Errorf("Divide(4000,00) should create panic call")
		}
	}()
	Divide(4000,0)
    
}

